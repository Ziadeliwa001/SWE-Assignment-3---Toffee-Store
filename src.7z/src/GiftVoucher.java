public class GiftVoucher {
    public char Code;
    public double SaleValue;
    public void CheckVoucherCode(char Code){};

}
