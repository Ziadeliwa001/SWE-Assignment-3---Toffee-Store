public class User {
    String Password;
    String Email;
    public void Custregister()
    {};
    public void Custlogin(char Email,char Password){};

}
