public enum StatusType  {
    INstock,
    OUTofstock;

}
