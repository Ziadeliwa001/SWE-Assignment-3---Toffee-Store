public interface Authentication {
    public boolean ValidatePass(String Password);
    public boolean ValidateEmail(String Email);

}
